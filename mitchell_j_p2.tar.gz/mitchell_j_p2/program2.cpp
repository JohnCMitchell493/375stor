#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <utility>
#include <cmath>

using namespace std;

class program2 {
public:
	program2(string inFile, string outFile) {
		int heapSize = -1;
		int arg1 = -1;
		int arg2 = -1;
		int emptyPos = 0;
		string instruction = "";
		string strArg1 = "";
		string strArg2 = "";
		ifstream input;
		ofstream output;
		input.open(inFile);
		input >> heapSize;
		pair<int,int> dummy(-1,0);
		pair<int,int> array[heapSize];
		//cout << "Makes Arrays" << endl;
		for(int i=0;i<heapSize;i++) array[i]=dummy;
		int locationArray[heapSize+1];
		for(int i=0;i<heapSize+1;i++) locationArray[i]=-1;
		//cout << "loc[5] = " << locationArray[heapSize] << endl;
		//cout << "Filled Arrays" << endl;
		output.open(outFile);
		//cout << "======= Start While Loop =======" << endl;
		while(input) {
			//cout << "------ Begins While Loop ------" << endl;
			input >> instruction;
			//cout << "Grabbed Instruction" << endl;
			if(instruction.compare("findContestant")==0) {		// parallel to Find(x,S)
				//cout << "read findContestant" << endl;
				input >> strArg1;
				arg1 = peelArgument(strArg1);
				output << instruction << " " << strArg1 << endl;
				output << findContestant(arg1,array,locationArray,heapSize) << endl;
			} else if(instruction.compare("insertContestant")==0) {
				//cout << "read insertContestant" << endl;
				input >> strArg1 >> strArg2;
				//cout << "About to Peel" << endl;
				arg1 = peelArgument(strArg1);
				//cout << "Peel 1" << endl;
				arg2 = peelArgument(strArg2);
				//cout << "Peel 2" << endl;
				//cout << "emptyPos = " << emptyPos << endl;
				output << instruction << " " << strArg1 << " " << strArg2 << endl;
				output << insertContestant(arg1, arg2, array, locationArray, emptyPos, heapSize) << endl;
				if((emptyPos>0)&&(emptyPos<=heapSize)) {
					buildMinHeap(array, locationArray, emptyPos, heapSize);
				}
				emptyPos++;
			} else if(instruction.compare("eliminateWeakest")==0) {		// parallel to extractMin
				//cout << "read eliminateWeakest" << endl;
				output << instruction << endl;
				output << eliminateWeakest(array, locationArray, emptyPos, heapSize) << endl;
			} else if(instruction.compare("earnPoints")==0) {
				//cout << "read earnPoints" << endl;
				input >> strArg1 >> strArg2;
				arg1 = peelArgument(strArg1);
				arg2 = peelArgument(strArg2);
				output << instruction << " " << strArg1 << " " << strArg2 << endl;
				output << earnPoints(arg1,arg2,array,locationArray) << endl;
				if((emptyPos>0)&&(emptyPos<=heapSize)) {
					buildMinHeap(array, locationArray, emptyPos, heapSize);
				}
			} else if(instruction.compare("losePoints")==0) {
				//cout << "losePoints" << endl;
				input >> strArg1 >> strArg2;
				arg1 = peelArgument(strArg1);
				arg2 = peelArgument(strArg2);
				output << instruction << " " << strArg1 << " " << strArg2 << endl;
				output << losePoints(arg1,arg2,array,locationArray) << endl;
				if((emptyPos>0)&&(emptyPos<=heapSize)) {
					buildMinHeap(array, locationArray, emptyPos, heapSize);
				}
			} else if(instruction.compare("showContestants")==0) {
				//cout << "read showContestants" << endl;
				output << instruction << endl;
				showContestants(array, heapSize, output);	// handles for loop locally, prints in order
										// 	found in main array
			} else if(instruction.compare("showHandles")==0) {
				//cout << "read showHandles" << endl;
				output << instruction << endl;
				showHandles(locationArray, heapSize+1, output);	// handles for loop locally, prints in order
										// 	found in locationArray
			} else if(instruction.compare("showLocation")==0) {
				//cout << "read showLocation" << endl;
				input >> strArg1;
				arg1 = peelArgument(strArg1);
				output << instruction << " " << strArg1  << endl;
				output << showLocation(arg1,locationArray) << endl;
			} else if(instruction.compare("crownWinner")==0) {	// it is reasonable to assume that crownWinner will 
										// 	be the last function called in an input file
				//cout << "read crownWinner" << endl;
				output << instruction << endl;
				//output << crownWinner(array, heapSize) << endl;
				output << crownWinner(array, emptyPos) << endl;
				break;
			} else {
				//cout << "read a unique function (WHOOPS)" << endl;
				output << "What the hell is " << instruction << arg1 << arg2 << " ?? Get that shit out of here." << endl;
			}
			/*cout << "Array currently contains:" << endl;
			for(int i=0;i<heapSize;i++) {
				cout << "\tElement " << i << " = " << array[i].first << " " << array[i].second << endl;
			}
			//cout << "Location Array currently contains:" << endl;
			for(int i=0;i<heapSize+1;i++) {
				cout << "\tElement " << i << " = " << locationArray[i] << endl;
			}*/
			//cout << "End of Loop" << endl;
		}
		input.close();
		output.close();
	}
	
	int peelArgument(string target) {
		string temp = target;
		//cout << temp << endl;
		//cout << temp[0] << endl;
		if(target[0]=='<') temp.erase(temp.begin());
		//cout << temp << endl;
		if(target[target.length()-1]=='>') temp.erase(temp.size()-1);
		//cout << temp << endl;
		return stoi(temp);
	}
	
	void minHeapify(pair<int,int> A[], int i, int size) {
		//cout << "Starting minHeapify" << endl;
		int l = 2*i;				// get array positions of children
		int r = 2*i+1;
		//int largest = -1;
		int smallestPos = -99;
		//if(l<=n)&&(A[l]>A[i]) {
		if((l <= size)&&(A[l].second < A[i].second)&&(A[l].first!=-1)) {
			//largest=l;
			smallestPos = l;
			//cout << "left child smaller than parent " << A[l].first << " " << A[l].second << endl;
		} else {
			//largest=i;
			smallestPos = i;
			//cout << "parent smaller than left child " << A[i].first << " " << A[i].second << endl;
		}
		//if(r<=n)&&(A[r]>A[largest]) {
		if((r <= size)&&(A[r].second < A[smallestPos].second)&&(A[r].first!=-1)) {
			//largest=r;
			smallestPos = r;
			//cout << "right child smaller than parent " << A[r].first << " " << A[r].second << endl;
		}
		//cout << "smallestPos = " << smallestPos << endl;
		//if(largest!=i) {
		if(smallestPos!=i) {
			int tempID = A[i].first;
			int tempScore = A[i].second;
			//cout << "Moving " << A[i].first << " " << A[i].second << endl;
			A[i] = A[smallestPos];
			//cout << "A[" << i << "] is now " << A[i].first << " " << A[i].second << endl;
			A[smallestPos].first = tempID;
			A[smallestPos].second = tempScore;
			//cout << "A[" << smallestPos << "] is now " << A[smallestPos].first << " " << A[smallestPos].second << endl;
			minHeapify(A, smallestPos, size);
		}
		//cout << "Ended minHeapify" << endl;
	}
	//TODO: Verify that this not-quite-pseudocode works
	void buildMinHeap(pair<int,int> A[], int loc[], int actingSize, int totalSize) {
		for(int i=(int)floor(actingSize/2);i>=0;i--) {
			minHeapify(A, i, actingSize);
			//cout << "Completed a minHeapify in buildMinHeap loop" << endl;
		}
		//cout << "Fixing Location Array" << endl;
		vector<int> usedIDs;
		bool inThere=false;
		for(int i=0;i<totalSize;i++) {
			loc[i]=-1;
		}
		for(int i=0;i<totalSize;i++) {
			//cout << "LocArrayFix LoopStart" << endl;
			if(A[i].first==-1) {
				for(long unsigned int j=0;j<usedIDs.size();j++) {
					if(i==usedIDs[j]) inThere=true;
				}
				if(inThere==false) {
					loc[i]=-1;
					//cout << "Position " << i << " set to -1" << endl;
				}
				
			} else {
				loc[A[i].first]=i;
				//cout << "Position " << A[i].first << " set to " << i << endl;
				usedIDs.push_back(A[i].first);
			}
		}
	}
	
	void speedyMinHeap(pair<int,int> A[], int size) {
		for(int i=(int)floor(size/2); i >= 0; i--) {
			minHeapify(A, i, size);
			//cout << "Completed a speedy minHeapify loop" << endl;
			//cout << "\ncrownWinner - Array looks like:" << endl;
			for(int j=0;j<size+1;j++) {
				//cout << "Element " << j << " = " << A[j].first << " " << A[j].second << endl;
				
			}
			//cout << endl;
		}
	}
	
	string findContestant(int id, pair<int,int> A[], int loc[], int size) {
		//if(id<size) cout << loc[id] << endl;
		if((loc[id]==-1)||(id>=size)) return ("Contestant <"+to_string(id)+"> is not in the extended heap.");
		return ("Contestant <"+to_string(id)+"> is in the extended heap with score <"+to_string(A[loc[id]].second)+">.");
	}
	
	string insertContestant(int id, int score, pair<int,int> A[], int loc[], int emptyPosition, int size) {
		if(emptyPosition>size) return ("Contestant <"+to_string(id)+"> could not be inserted because the extended heap is full.");
		for(int i=0;i<emptyPosition;i++) {
			if(A[i].first==id) return ("Contestant <"+to_string(id)+"> is already in the extended heap: cannot insert.");
		}
		//cout << "emptyPosition = " << emptyPosition << endl;
		A[emptyPosition] = make_pair(id,score);
		//cout << "Inserted " << A[emptyPosition].first << " " << A[emptyPosition].second << endl;
		//cout << "Inserted " << A[emptyPosition-1].first << " " << A[emptyPosition-1].second << endl;
		loc[id]=emptyPosition;
		return ("Contestant <"+to_string(id)+"> inserted with inital score <"+to_string(score)+">.");
	}
	//TODO: this is dubious at best, minheap is a fucking mess right now
	string eliminateWeakest(pair<int,int> A[], int loc[], int endPos, int totalSize) {
		if(endPos < 1) return ("No contestant can be eliminated since the extended heap is empty.");
		int minID = A[0].first;
		int minScore = A[0].second;
		A[0].first = A[endPos-1].first;
		A[0].second = A[endPos-1].second;
		//cout << "A[endPos].first=" << A[endPos-1].first << endl;
		A[endPos-1].first = -1;
		A[endPos-1].second = 0;
		//cout << "A[endPos].first=" << A[endPos-1].first << endl;
		endPos--;
		buildMinHeap(A,loc,endPos-1,totalSize);
		return ("Contestant <"+to_string(minID)+"> with current lowest score <"+to_string(minScore)+"> eliminated.");
		
	}
	
	pair<int,int> purge(pair<int,int> A[], int size) {
		int ogsize = size;
		for(int i=0;i<ogsize;i++) {
			//A[0] = A[size];
			A[0].first = A[size].first;
			A[0].second = A[size].second;
			A[size].first = -1;
			A[size].second = 0;
			size--;
			if(size!=0) {
				speedyMinHeap(A, size);
			} else {
				return A[0];
			}
		}
		pair<int,int> fucked(-1,-69);
		//cout << "|||| Ohhh, something went very wrong. ||||" << endl;
		return fucked;
	}
	
	string earnPoints(int id, int points, pair<int,int> A[], int loc[]) {
		if(loc[id]==-1) return ("Contestant <"+to_string(id)+"> is not in the extended heap.");
		A[loc[id]].second += points;
		return ("Contestant <"+to_string(id)+">'s score increased by <"+to_string(points)+"> points to <"+to_string(A[loc[id]].second)+">.");
	}
	
	string losePoints(int id, int points, pair<int,int> A[], int loc[]) {
		if(loc[id]==-1) return ("Contestant <"+to_string(id)+"> is not in the extended heap.");
		A[loc[id]].second -= points;
		return ("Contestant <"+to_string(id)+">'s score decreased by <"+to_string(points)+"> points to <"+to_string(A[loc[id]].second)+">.");
	}
	
	void showContestants(pair<int,int> A[], int size, ofstream &f) {
		//cout << "in showContestants" << endl;
		for(int i = 0; i < size; i++) {
			if(A[i].first!=-1) {
				//cout << A[i].first << " " << A[i].second << endl;
				f << "Contestant <" << A[i].first << "> in extendedheap location <" << i+1 << "> with score <" << A[i].second << ">." << endl;
			}
		}
	}
	
	void showHandles(int loc[], int size, ofstream &f) {
		for(int i = 1; i < size; i++) {
			if(loc[i]==-1) {
				f << "There is no Contestant <" << i << "> in the extended heap: handle[<" << i << ">]=-1." << endl;
			} else {
				f << "Contestant <" << i << "> stored in extended heap location <" << loc[i]+1 << ">." << endl;
			}
		}
	}
	
	string showLocation(int id, int loc[]) {
		if(loc[id]==-1) return ("There is no Contestant <"+to_string(id)+"> in the extended heap: handle[<"+to_string(id)+">]=-1");
		return ("Contestant <"+to_string(id)+"> stored in extended heap location <"+to_string(loc[id])+">.");
		
	}
	
	string crownWinner(pair<int,int> A[], int size) {
		pair<int,int> winner = purge(A, size);
		return("Contestant <"+to_string(winner.first)+"> wins with score <"+to_string(winner.second)+">!");
	}
	
};

int main(int argc, char *argv[]) {
	string inputFile = argv[1];
	string outputFile = argv[2];
	program2(inputFile, outputFile);
}
