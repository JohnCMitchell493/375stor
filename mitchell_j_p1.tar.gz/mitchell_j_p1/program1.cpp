#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <cstring>
#include <cmath>
#include <utility>
#include <chrono>
#include <tuple>

using namespace std;

class program1 {
public:
	program1(string f1, string f2) {
		int marketItems;
		ifstream marketFile;
		ifstream priceFile;
		ofstream outputFile;
		marketFile.open(f1);
		marketFile >> marketItems;
		string marketNames[marketItems] = {""};
		int marketPrices[marketItems] = {0};
		populateMarket(marketNames, marketPrices, marketItems, marketFile);
		marketFile.clear();
		marketFile.close();
		priceFile.open(f2);
		outputFile.open("output.txt");
		comparePrices(marketNames, marketPrices, marketItems, priceFile, outputFile);
		priceFile.clear();
		priceFile.close();
		outputFile.close();
	}
	
	void populateMarket(string nameArray[], int priceArray[], int priceSize, ifstream &market) {
		string name;
		int price;
		for(int i = 0; i < priceSize; i++) {
			market >> name >> price;
			nameArray[i] = name;
			priceArray[i] = price;
		}
	}
	
	int getBinaryValue(vector<bool> binaryArray, int binarySize) {
		int numTrues = 0;
		for(int i=0; i<binarySize; i++) {
			if(binaryArray[i]==true) {
				numTrues++;
			}
		}
		//cout << "getBinaryValue found " << numTrues << " trues" << endl;
		return numTrues;
	}
	
	void comparePrices(string marketNames[], int marketPrices[], int marketNameSize, ifstream &priceFile, ofstream &outFile) {
		int problemItemNum;
		int problemBudget;
		string problemItemName;
		int problemItemCost;
		int problemTotaCost = 0;
		long int problemTotaProfit = 0;
		bool nuclearOption = false;
		chrono::steady_clock::time_point start;
		chrono::steady_clock::time_point end;
		pair<string,int> item;
		vector<pair<string,int>> problemItems;
		vector<string> tempNames;
		vector<tuple<int,int,vector<string>>> validCombinations;
		while(priceFile) {
			priceFile >> problemItemNum >> problemBudget;
			//cout << "Starting Problem. Items: " << problemItemNum << "; Budget: " << problemBudget << endl;
			for(int j = 0; j < problemItemNum; j++) {
				priceFile >> problemItemName >> problemItemCost;
				for(int i = 0; i < marketNameSize; i++) {
					if(problemItemName.compare(marketNames[i]) == 0) break;		// assumes that all items in price list exist in market list
				}
				item.first = problemItemName;
				//cout << "Read Name: " << item.first << endl;
				item.second = problemItemCost;
				//cout << "Read Cost: " << item.second << endl;
				problemItems.push_back(item);
			}
			
			/*
			In order to fix a bug where ifstream priceFile reads the last line of the file twice, and creates a problem which does not exist using existing, untrashed data
				and as many iterations of the final element of the last problem as that last problem had card-price pairs, the following check exists. No two cards in 
				a given problem should have exactly identical string names. If this happens, as found by the for loop below, terminate immediately using nuclearOption.
			*/
			
			for(long unsigned int j = 0; j < problemItems.size(); j++) {
				for(long unsigned int k = 0; k < problemItems.size(); k++) {
					if(j==k) continue;
					else if(problemItems[j].first.compare(problemItems[k].first)==0) {
						//cout << "FAULTY: " << problemItems[j].first << " ; " << problemItems[k].first << endl;
						nuclearOption = true;
						break;
					}
				}
				if(nuclearOption) break;
			}
			if(nuclearOption) {
				//cout << "MAN WHO SOLD THE WORLD" << endl;
				break;
			}
			vector<bool> binarySelect;
			for(int j = 0; j < problemItemNum; j++) {
				binarySelect.push_back(false);
			}
			
			start = chrono::steady_clock::now();
			
			//cout << "Begin combination generation..." << endl;
			
			for(int k = 0; k < ((int)(pow(2.0, (float)problemItemNum))); k++) {		// combination selection
				//cout << "Combination k = " << k << endl;
				
				for(int j = 0; j < problemItemNum; j++) {				// fill a permutation
					if(binarySelect[j] == true) {
						problemTotaCost += problemItems[j].second;
						for(int m = 0; m < marketNameSize; m++) {		// find market value
							if((problemItems[j].first).compare(marketNames[m])==0) {
								problemTotaProfit += marketPrices[m];
								break;
							}
						}
						tempNames.push_back(problemItems[j].first);		// add name to list
					}
				}
				
				//cout << "Combination " << k << " filled" << endl;
				
				if(problemTotaCost <= problemBudget) {					// add valid combination to list
					//cout << "Combo Profit: " << (problemTotaProfit - problemTotaCost) << endl;
					//cout << "Combo Number of Elements: " << getBinaryValue(binarySelect,problemItemNum) << endl;
					validCombinations.push_back(make_tuple((problemTotaProfit -problemTotaCost),(getBinaryValue(binarySelect,problemItemNum)),tempNames));
					// Combination Profit , Number of Cards Chosen , List of Named Cards contained in Combination
				}
				
				//cout << "Combination Tuple generated and pushed" << endl;
				
				if(binarySelect[0]==false) {						// update binary select
					binarySelect[0]=true;
					//cout << "BASE: Set binSelect index " << 0 << " to " << binarySelect[0] << endl;
				} else {
					for(int q = 1; q < problemItemNum; q++) {
						if(binarySelect[q] == false) {
							binarySelect[q] = true;
							//cout << "ITER: Set binSelect index " << q << " to " << binarySelect[q] << endl;
							for(int p = q-1; p >= 0; p--) {
								binarySelect[p] = false;
								//cout << "iterLOOP: Set binSelect index " << p << " to " << binarySelect[p] << endl;
							}
							break;
						}
					}
				}
				
				//cout << "binary updated" << endl;
				tempNames.clear();
				problemTotaProfit = 0;
				problemTotaCost = 0;
			}
			
			//cout << "All combinations generated!" << endl;
			
			tempNames.clear();
			//cout << "tempNames cleared" << endl;
			
			problemTotaProfit = 0;
			
			int check = 999;
			for(long unsigned int n = 0; n < validCombinations.size(); n++ ) {
				if(get<0>(validCombinations[n]) > problemTotaProfit) check = n;
			}
			//cout << "maximum profit index found" << endl;
			
			end = chrono::steady_clock::now();
			float elapsedTime = chrono::duration_cast<chrono::seconds>(end-start).count();		// prompt says to give it in seconds, so inputs will likely be large enough to matter
			outFile << problemItemNum << "\t" << get<0>(validCombinations[check]) << "\t" << get<1>(validCombinations[check]) << "\t" << elapsedTime << endl;
			tempNames = get<2>(validCombinations[check]);
			for(long unsigned int r = 0; r < tempNames.size(); r++) {
				outFile << tempNames[r] << endl;
			}
			//cout << "outFile filled with named results!" << endl;
			// reset old data
			tempNames.clear();
			validCombinations.clear();
			problemItems.clear();
			problemTotaCost = 0;
			problemTotaProfit = 0;
			
			//cout << "Problem completed!" << endl << endl;
			//cout << "Up next: " << priceFile.peek() << endl << endl;
		}
	}

};

int main(int argc, char *argv[]) {
	string file1;
	string file2;
	if(strcmp(argv[1], "-m")==0) {
		file1=argv[2];
	} else {
		throw "Incorrect Format, ' -m <MarketListFile> -p <PriceListFile> '";
	}
	if(strcmp(argv[3], "-p")==0) {
		file2=argv[4];
	} else {
		throw "Incorrect Format, ' -m <MarketListFile> -p <PriceListFile> '";
	}
	program1(file1, file2);
}
