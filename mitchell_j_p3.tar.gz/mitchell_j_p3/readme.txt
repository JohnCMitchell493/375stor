C++
make

code can receive a fourth argument on the command line, which should only contain "debug", which will include print statements used in debugging.

additionally, the fourth argument sent to the output files, the list of used items, is referred to by weight and not by position in the list.
	this was unclear in the program assignment document, but would be easily fixable if given the opportunity. Please reach out to me if this was a 
	miscommunication.
	
no idea how lossy the program is. There are no explicit mallocs, and it handled the mediumInput file fine, but the limits of this haven't been tested.

there might also be a hidden file with a name like tempInput.txt, and if so it means i couldn't get rid of it. sorry for the inconvenience.
	
I have done this assignment completely on my own. I have not copied it, nor have I given the solution to anyone else. I understand that if I am involved in plagiarism or cheating I will have to sign an official form that I have cheated and that this form will be stored in my official university record. I also understand that I will receive a grade of 0 for the involved assignment for my first offense and that I will receive a grade of "F" for the course for any additional offense.
Signed: John Mitchell
	B005889974
	04/13/2022
