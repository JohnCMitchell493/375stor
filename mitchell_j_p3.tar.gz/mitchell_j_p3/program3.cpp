#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <utility>
#include <chrono>
#include <algorithm>
#include <tuple>
#include <cstring>

using namespace std;

class Program3 {
public:
	Program3(string in, string out, int op, bool debug) {
		if(debug) cout << "Running in debug mode...\n\n" << endl;
		ifstream input;
		ofstream output;
		int problemSize = -1;
		int cap = -1;
		int itemWei = -1;
		int itemVal = -1;
		vector<tuple<double,int,int>> vec;
		pair<int,vector<int>> ans;
		chrono::steady_clock::time_point start;
		chrono::steady_clock::time_point end;
		float elapsedTime;
		input.open(in);
		output.open(out);
		while(input >> problemSize >> cap) {
		
			if(debug) cout << "\nPhase 1: Get Problem\n" << endl;
			for(int i=0; i<problemSize; i++) {
				input >> itemWei >> itemVal;
				// all algs sort by nonincreasing p/w
				vec.push_back(make_tuple(((double)itemVal/itemWei), itemWei, itemVal));
				if(debug) cout << "p/w w p" << " " << (double)itemVal/itemWei << " " << itemWei << " " << itemVal << endl;
			}
			vec = manualSort(vec, debug);
			if(debug) {
				cout << "vec post-sort:" << endl;
				for(long unsigned int i=0;i<vec.size();i++) cout << " " << (double)get<0>(vec[i]) << " " << get<1>(vec[i]) << " " << get<2>(vec[i]) << endl;
			}
			
			if(debug) cout << "\nPhase 2: Perform Algorithm\n" << endl;
			switch(op){
				case 0:		/* Greedy1 */
					start = chrono::steady_clock::now();
					ans = greedy1(cap, vec, debug);
					end = chrono::steady_clock::now();
					break;
				case 1:		/* Greedy2 */
					start = chrono::steady_clock::now();
					ans = greedy2(cap, vec, debug);
					end = chrono::steady_clock::now();
					break;
				case 2:		/* Backtracking */
					start = chrono::steady_clock::now();
					ans = backtracking(cap, vec, debug);
					end = chrono::steady_clock::now();
					break;
			}
			
			if(debug) cout << "\nPhase 3: Output\n" << endl;
			elapsedTime = chrono::duration_cast<chrono::milliseconds>(end-start).count();
			output << problemSize << " " << ans.first << " " << elapsedTime;
			for(long unsigned int j=0; j<ans.second.size();j++) output << " " << ans.second[j];
			output << endl;
			
			if(debug) cout << "\nPhase 4: Cleanup\n" << endl;
			ans.first = -1;
			ans.second.clear();
			vec.clear();
			elapsedTime = 0.0;
		}
		input.close();
		output.close();
	}
	
	vector<tuple<double,int,int>> manualSort(vector<tuple<double,int,int>> v, bool debug) {
		if(debug) cout << "Sorting it myself. can't have shit in detroit." << endl;
		//this is a bubble sort. yes it is inefficient but it is one i can implement quickly
		tuple<double,int,int> temp;
		for(long unsigned int i=0; i<v.size(); i++) {
			for(long unsigned int j=0; j<v.size()-i; j++) {
				if((j+1)<v.size()) {
					if(get<0>(v[j]) < get<0>(v[j+1])) {
						temp = v[j];
						v[j] = v[j+1];
						v[j+1] = temp;
						if(debug) cout << "swapped two elements" << endl;
					}
				}
			}
		}
		return v;
	}
	
	pair<int, vector<int>> greedy1(int cap, vector<tuple<double,int,int>> v, bool debug) {
		if(debug) cout << "Greedy1 Algorithm Start" << endl;
		pair<int, vector<int>> ans;
		int maxProfit = 0;
		int curWeight = 0;
		vector<int> finalists;
		for(long unsigned int i=0; i<v.size(); i++) {
			if((curWeight+get<1>(v[i]))<cap) {
				finalists.push_back(get<1>(v[i]));
				if(debug) cout << "pushed back " << get<1>(v[i]) << endl;
				maxProfit+=get<2>(v[i]);
				curWeight+=get<1>(v[i]);
			}
		}
		ans.first = maxProfit;
		ans.second = finalists;
		if(debug) cout << "Greedy1 Algorithm End" << endl;
		return ans;
	}
	
	pair<int, vector<int>> greedy2(int cap, vector<tuple<double,int,int>> v, bool debug) {
		if(debug) cout << "Greedy2 Algorithm Start" << endl;
		pair<int, vector<int>> ans;
		pair<int, vector<int>> greedy = greedy1(cap, v, debug);
		int maxProfit = -1;
		int finalistWeight = -1;
		for(long unsigned int i=0; i<v.size(); i++) {
			if((maxProfit<(get<2>(v[i]))) && ((get<1>(v[i])<=cap))) {
				finalistWeight = get<1>(v[i]);
				maxProfit = get<2>(v[i]);
			}
		}
		if((greedy.first)>maxProfit) {
			ans.first = greedy.first;
			ans.second = greedy.second;
		} else {
			ans.first = maxProfit;
			ans.second.push_back(finalistWeight);
		}
		if(debug) cout << "Greedy2 Algorithm End " << ans.first << " " << ans.second.size() << endl;
		return ans;
	}
	
	int findBound(int i, int weight, int profit, vector<tuple<double,int,int>> v, int C, vector<int> x, bool debug) {
		// i: item number; C: capacity; n: size
		// x: include
		if(debug) cout << "findBound Start" << endl;
		int bound = profit;
		for(long unsigned int j=i; j<x.size()-1; j++) {
			x[j]=0;
		}
		long unsigned int k = (long unsigned int)i;
		while((weight<C)&&(k<=x.size()-1)) {
			if((weight+(get<1>(v[k])))<=C) {
				x[k]=1;
				weight=weight+(get<1>(v[k]));
				bound=bound+(get<2>(v[k]));
			} else {
				x[k]=(C-weight)/(get<1>(v[k]));
				weight=C;
				bound=bound+((get<2>(v[k]))*x[k]);
			}
			k=k+1;
		}
		return bound;
	}
	
	bool promising(int item, int profit, int weight, int C, int maxprofit, vector<tuple<double,int,int>> v, vector<int> include, bool debug) {
		if(debug) cout << "Promising Start" << endl;
		if((weight>=C)||(include[item+1]==2)) return false;
		vector<int> copy = include;
		int bound = findBound(item+1, weight, profit, v, C, copy, debug);
		return(bound>maxprofit);
	}
	
	void knapsack(int item, int profit, int weight, int cap, vector<tuple<double,int,int>> v, vector<int> include, vector<int> bestset, int maxprofit, bool debug) {
		if(debug) cout << "Called Knapsack()" << endl;
		if((weight<=cap)&&(profit>maxprofit)) {
			if(debug) cout << "Found a new best path!" << endl;
			maxprofit = profit;
			bestset = include;
			if(debug) {
				cout << "Include Right Now:" << endl;
				for(long unsigned int i=0;i<include.size();i++) cout << " " << include[i] << endl;
				cout << "Bestset Right Now:" << endl;
				for(long unsigned int i=0;i<bestset.size();i++) cout << " " << bestset[i] << endl;
			}
		}
		if(promising(item, profit, weight, cap, maxprofit, v, include, debug)) {
			if(debug) cout << "This looks promising!" << endl;
			include[item+1]=1;
			knapsack(item+1, profit+get<2>(v[item+1]), weight+get<1>(v[item+1]),cap,v,include,bestset,maxprofit,debug);
			include[item+1]=0;
			knapsack(item+1, profit, weight,cap,v,include,bestset,maxprofit,debug);
		}
		if(debug) {
				cout << "--Include right as Knapsack Ends:" << endl;
				for(long unsigned int i=0;i<include.size();i++) cout << " " << include[i] << endl;
				cout << "Bestset right as Knapsack Ends:" << endl;
				for(long unsigned int i=0;i<bestset.size();i++) cout << " " << bestset[i] << endl;
		}
	}
	
	
	pair<int, vector<int>> backtracking(int cap, vector<tuple<double,int,int>> v, bool debug) {
		if(debug) cout << "Backtracking Algorithm Start" << endl;
		pair<int, vector<int>> ans;
		vector<int> include;
		for(long unsigned int i=0;i<v.size();i++) include.push_back(0);
		include.push_back(2);		// acts as end-of-list character for knapsack & promising
		
		if(debug) for(long unsigned int i=0;i<v.size();i++) cout << " " << get<1>(v[i]) << endl;
		pair<int, vector<int>> temp = greedy2(cap, v, debug);
		int maxProfit = temp.first;
		vector<int> HARD = temp.second;
		vector<int> bestset;
		int j=0;
		for(long unsigned int i=0; i<v.size();i++) {		// get bestset includes from greedy2 vector
			if(get<1>(v[i])==HARD[j]) {
				bestset.push_back(1);
				if(debug) cout << "backtracking init pushed a 1" << endl;
				j++;
			} else { 
				bestset.push_back(0);
				if(debug) cout << "backtracking init pushed a 0" << endl;
			}
		}
		bestset.push_back(2);		// end-of-list char like include has
		if(debug) {
			cout << "Include Right Now:" << endl;
			for(long unsigned int i=0;i<include.size();i++) cout << " " << include[i] << endl;
			cout << "Bestset Right Now:" << endl;
			for(long unsigned int i=0;i<bestset.size();i++) cout << " " << bestset[i] << endl;
		}
		knapsack(0,0,0,cap, v, include, bestset, maxProfit, debug);
		if(debug) {
			cout << "Include Before Processing:" << endl;
			for(long unsigned int i=0;i<include.size();i++) cout << " " << include[i] << endl;
			cout << "Bestset Before Processing:" << endl;
			for(long unsigned int i=0;i<bestset.size();i++) cout << " " << bestset[i] << endl;
		}
		
		vector<int> finalists;
		for(long unsigned int i=0; i<v.size();i++) {
			if(debug) cout << "Started loop in final backtrack combiner" << endl;
			if(bestset[i]==1) {
				finalists.push_back(get<1>(v[i]));
				if(debug) cout << "added " << get<1>(v[i]) << " to finalist vec" << endl;
			}
		}
		ans.first = maxProfit;
		ans.second = finalists;
		if(debug) cout << "Backtracking Algorithm End" << endl;
		return ans;
	}

};

int main(int argc, char *argv[]) {
	string infile = argv[1];
	string outfile = argv[2];
	int operation = stoi(argv[3]);
	if(argc<5) {
		Program3(infile, outfile, operation, false);
	} else if(strcmp(argv[4],"debug")==0) {		// debug mode, remove if needed
		Program3(infile, outfile, operation, true);
	} else {
		cout << "Undefined behavior! arg[4] not 'debug' or too many args" << endl;
	}
	return 0;
}
