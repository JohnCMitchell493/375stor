#include <iostream>
#include <stdlib.h>
#include <cmath>
#include <vector>
#include <algorithm>
#include <chrono>
#include "HashTable.h"
#define MAX 100000
#define MIN 10


/*Imported from Testgen*/
int** buildTests(int size) {
	int** fArray;
	fArray=new int*[3];
	for(int i = 0; i < 3; i++) fArray[i]=new int[size];
	int randPosition = rand() % 10;
	for(int i = 0; i<size; i++) {
		if(i%10==randPosition) {
			fArray[0][i]=i;
			fArray[0][i+1]=i;
			randPosition=rand()%10;
			i++;
		} else {
			fArray[0][i]=i;
		}
	}
	std::vector<int> shuffleTemp;
	for(int i=0; i<size; i++) shuffleTemp.push_back(i);
	std::random_shuffle(shuffleTemp.begin(), shuffleTemp.end());
	for(int i=0; i<size; i++) fArray[1][i]=shuffleTemp[i];
	for(int i=0; i<size; i++) fArray[2][i]=(int)rand();
	return fArray;
}
/*
//Hash functions
int divisionMethod(int k, int m){
    return k%m;
}
int multiplicationMethod(int k, int m){
    double a=(sqrt(5)-1)/2;
    return floor(m*(k*a-floor(k*a)));
}

//Probing techniques
int linearProbe(int i, int m, int hashedK){
    return (hashedK+i)%m;
}
int quadraticProbe(int i, int m, int hashedK){
    int c1=1;
    int c2=1;
    return (hashedK+i+pow(i,2))%m;
}
int doubleHash(int i, int m, int hashedK){
    //uses same hash func for h1&h2
    return (hashedK+i*hashedK)%m;
}
*/
void testLinearProbe(){
    HashTable tables[(int)log10(MAX/MIN)+1][3];
    int** testInputs[(int)log10(MAX/MIN)+1];
    for(int i=MIN;i<=MAX;i=i*10){
        for(int j=0;j<3;j++)
        tables[(int)log10(i)-1][j]=HashTable(i);
        testInputs[(int)log10(i)-1]=buildTests(i);
    }
    std::cout<<"-----------------------Linear Probe----------------------------"<<std::endl;
    //div
    //insert
    std::cout<<std::endl;
    std::cout<<"--------Division Method--------"<<std::endl;
    std::cout<<std::endl;
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].InsertDLP(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Inserting "<<(int)tables[i][0].size<<" elements into hash table of size "<<(int)tables[i][0].size<<" using linear probing and the division method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].SearchDLP(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Searching "<<(int)tables[i][0].size<<" elements in hash table of size "<<(int)tables[i][0].size<<" using linear probing and the division method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].DeleteDLP(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Deleting "<<(int)tables[i][0].size<<" elements from hash table of size "<<(int)tables[i][0].size<<" using linear probing and the division method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
    std::cout<<std::endl;
    std::cout<<"--------Multiplication Method--------"<<std::endl;
    std::cout<<std::endl;
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            for(long unsigned int j=0;j<tables[i][n].size;j++){
                tables[i][n].table[j]=-2;
            }
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].InsertMLP(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Inserting "<<(int)tables[i][0].size<<" elements into hash table of size "<<(int)tables[i][0].size<<" using linear probing and the multiplication method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].SearchMLP(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Searching "<<(int)tables[i][0].size<<" elements in hash table of size "<<(int)tables[i][0].size<<" using linear probing and the multiplication method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].DeleteMLP(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Deleting "<<(int)tables[i][0].size<<" elements from hash table of size "<<(int)tables[i][0].size<<" using linear probing and the multiplication method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
}
void testQuadraticProbe(){
    HashTable tables[(int)log10(MAX/MIN)+1][3];
    int** testInputs[(int)log10(MAX/MIN)+1];
    for(int i=MIN;i<=MAX;i=i*10){
        for(int j=0;j<3;j++)
        tables[(int)log10(i)-1][j]=HashTable(i);
        testInputs[(int)log10(i)-1]=buildTests(i);
    }
    std::cout<<"-----------------------Quadratic Probe----------------------------"<<std::endl;
    //div
    //insert
    std::cout<<std::endl;
    std::cout<<"--------Division Method--------"<<std::endl;
    std::cout<<std::endl;
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].InsertDQP(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Inserting "<<(int)tables[i][0].size<<" elements into hash table of size "<<(int)tables[i][0].size<<" using quadratic probing and the division method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].SearchDQP(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Searching "<<(int)tables[i][0].size<<" elements in hash table of size "<<(int)tables[i][0].size<<" using quadratic probing and the division method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].DeleteDQP(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Deleting "<<(int)tables[i][0].size<<" elements from hash table of size "<<(int)tables[i][0].size<<" using quadratic probing and the division method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
    std::cout<<std::endl;
    std::cout<<"--------Multiplication Method--------"<<std::endl;
    std::cout<<std::endl;
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            for(long unsigned int j=0;j<tables[i][n].size;j++){
                tables[i][n].table[j]=-2;
            }
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].InsertMQP(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Inserting "<<(int)tables[i][0].size<<" elements into hash table of size "<<(int)tables[i][0].size<<" using quadratic probing and the multiplication method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].SearchMQP(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Searching "<<(int)tables[i][0].size<<" elements in hash table of size "<<(int)tables[i][0].size<<" using quadratic probing and the multiplication method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].DeleteMQP(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Deleting "<<(int)tables[i][0].size<<" elements from hash table of size "<<(int)tables[i][0].size<<" using quadratic probing and the multiplication method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
}
void testDoubleHash(){
    HashTable tables[(int)log10(MAX/MIN)+1][3];
    int** testInputs[(int)log10(MAX/MIN)+1];
    for(int i=MIN;i<=MAX;i=i*10){
        for(int j=0;j<3;j++)
        tables[(int)log10(i)-1][j]=HashTable(i);
        testInputs[(int)log10(i)-1]=buildTests(i);
    }
    std::cout<<"-----------------------Double Hash----------------------------"<<std::endl;
    //div
    //insert
    std::cout<<std::endl;
    std::cout<<"--------Division Method--------"<<std::endl;
    std::cout<<std::endl;
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].InsertDDH(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Inserting "<<(int)tables[i][0].size<<" elements into hash table of size "<<(int)tables[i][0].size<<" using double hashing and the division method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].SearchDDH(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Searching "<<(int)tables[i][0].size<<" elements in hash table of size "<<(int)tables[i][0].size<<" using double hashing and the division method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].DeleteDDH(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Deleting "<<(int)tables[i][0].size<<" elements from hash table of size "<<(int)tables[i][0].size<<" using double hashing and the division method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
    std::cout<<std::endl;
    std::cout<<"--------Multiplication Method--------"<<std::endl;
    std::cout<<std::endl;
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            for(long unsigned int j=0;j<tables[i][n].size;j++){
                tables[i][n].table[j]=-2;
            }
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].InsertMDH(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Inserting "<<(int)tables[i][0].size<<" elements into hash table of size "<<(int)tables[i][0].size<<" using double hashing and the multiplication method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].SearchMDH(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Searching "<<(int)tables[i][0].size<<" elements in hash table of size "<<(int)tables[i][0].size<<" using double hashing and the multiplication method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
    for(int i=0;i<=(int)log10(MAX/MIN);i++){
        for(int n=0;n<3;n++){
            std::chrono::high_resolution_clock::time_point start(std::chrono::high_resolution_clock::now());
            for(long unsigned int t=0;t<tables[i][n].size;t++){
                tables[i][n].DeleteMDH(testInputs[i][n][t]);
            }
            std::chrono::high_resolution_clock::time_point finish(std::chrono::high_resolution_clock::now());
            std::cout<<"Deleting "<<(int)tables[i][0].size<<" elements from hash table of size "<<(int)tables[i][0].size<<" using double hashing and the multiplication method took "<<std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count()<<"ns"<<std::endl;
        }
        std::cout<<std::endl;
    }
}
int main(int argc, char *argv[]){
    testLinearProbe();
    testQuadraticProbe();
    testDoubleHash();
    return 0;
}
