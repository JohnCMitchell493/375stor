#ifndef HASHTABLE_H
#define HASHTABLE_H

#include <cmath>
#include <iostream>
#include <cstdlib>
#include <vector>
//using namespace std;

//-2 = NIL -1 = DELETED
class HashTable
{
    public:
        int* table;
        long unsigned int size;
        HashTable(int r);
        HashTable();
        bool SearchDLP(int key);
        int InsertDLP(int key);
        int DeleteDLP(int key);
        bool SearchMLP(int key);
        int InsertMLP(int key);
        int DeleteMLP(int key);
        bool SearchDQP(int key);
        int InsertDQP(int key);
        int DeleteDQP(int key);
        bool SearchMQP(int key);
        int InsertMQP(int key);
        int DeleteMQP(int key);
        bool SearchDDH(int key);
        int InsertDDH(int key);
        int DeleteDDH(int key);
        bool SearchMDH(int key);
        int InsertMDH(int key);
        int DeleteMDH(int key);
        int divisionMethod(int key, int m) {
        	return (key%m);
        }
        int multiplicationMethod(int key, int m) {
        	double a=(sqrt(5)-1)/2;
        	return floor(m*(key*a-floor(key*a)));
        }
        //int linearProbe(int i, int m, int hashedK);
        //int linearProbe(int,int,int);
        int linearProbe(int i, int m, int hashedK) {
        	return ((hashedK+i)%m);
        }
        int quadraticProbe(int i, int m, int hashedK) {
        	return ((int)(hashedK+i+pow(i,2))%m);
        }
        int doubleHash(int i, int m, int hashedK) {
        	return ((hashedK+i*hashedK)%m);
        }
};
HashTable::HashTable(int r)
{
    size=r;
    table=new int[r];
    for (long unsigned int i=0;i<size;i++){
        table[i]=-2;
    }
}
HashTable::HashTable(){}

/*int HashTable::divisionMethod(int k, int m){
    return k%m;
}
int multiplicationMethod(int k, int m){
    double a=(sqrt(5)-1)/2;
    return floor(m*(k*a-floor(k*a)));
}

//Probing techniques
int linearProbe(int i, int m, int hashedK){
   return (hashedK+i)%m;
}
int quadraticProbe(int i, int m, int hashedK){
    //int c1=1;
    //int c2=1;
    return ((int)(hashedK+i+pow(i,2))%m);
}
int doubleHash(int i, int m, int hashedK){
    //uses same hash func for h1&h2
    return (hashedK+i*hashedK)%m;
}*/

//---------------------------DIVISION LINEAR PROBE------------------------
bool HashTable::SearchDLP(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=divisionMethod(key,size);
    for(i = 0; i < size; i++)
    {
        j=linearProbe(i, (int)size, ogHash);
        if (table[j]==key)
        {
            return true;
        }
        else if (table[j]==-2)
        {
            return false;
        }
    }
    return false;
}
int HashTable::InsertDLP(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=divisionMethod(key,size);
    for(i=0;i<size;i++)
    {
        j=linearProbe(i, (int)size, ogHash);
        if(table[j] == -2 || table[j] == -1)
        {
            table[j] = key;
            return j;
        }
    }    
    return -2;
}
int HashTable::DeleteDLP(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=divisionMethod(key,size);
    for(i = 0; i < size; i++)
    {
        j=linearProbe(i, (int)size, ogHash);
        if (table[j]==key)
        {
            return j;
            table[j]=-1;
        }
        else if (table[j]==-2)
        {
            return -2;
        }
    }
    return -2;
}




//---------------------------MULTIPLICATION LINEAR PROBE------------------------
bool HashTable::SearchMLP(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=multiplicationMethod(key,size);
    for(i = 0; i < size; i++)
    {
        j=linearProbe(i,(int)size, ogHash);
        if (table[j]==key)
        {
            return true;
        }
        else if (table[j]==-2)
        {
            return false;
        }
    }
    return false;
}
int HashTable::InsertMLP(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=multiplicationMethod(key,size);
    for(i=0;i<size;i++)
    {
        j=linearProbe(i, (int)size, ogHash);
        if(table[j] == -2 || table[j] == -1)
        {
            table[j] = key;
            return j;
        }
    }    
    return -2;
}
int HashTable::DeleteMLP(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=multiplicationMethod(key,size);
    for(i = 0; i < size; i++)
    {
        j=linearProbe(i, (int)size, ogHash);
        if (table[j]==key)
        {
            return j;
            table[j]=-1;
        }
        else if (table[j]==-2)
        {
            return -2;
        }
    }
    return -2;
}




//---------------------------DIVISION QUADRATIC PROBE------------------------
bool HashTable::SearchDQP(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=divisionMethod(key,size);
    for(i = 0; i < size; i++)
    {
        j=quadraticProbe(i,size, ogHash);
        if (table[j]==key)
        {
            return true;
        }
        else if (table[j]==-2)
        {
            return false;
        }
    }
    return false;
}
int HashTable::InsertDQP(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=divisionMethod(key,size);
    for(i=0;i<size;i++)
    {
        j=quadraticProbe(i, size, ogHash);
        if(table[j] == -2 || table[j] == -1)
        {
            table[j] = key;
            return j;
        }
    }    
    return -2;
}
int HashTable::DeleteDQP(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=divisionMethod(key,size);
    for(i = 0; i < size; i++)
    {
        j=quadraticProbe(i, size, ogHash);
        if (table[j]==key)
        {
            table[j]=-1;
            return j;
        }
        else if (table[j]==-2)
        {
            return -2;
        }
    }
    return -2;
}




//---------------------------MULTIPLICATION QUADRATIC PROBE------------------------
bool HashTable::SearchMQP(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=multiplicationMethod(key,size);
    for(i = 0; i < size; i++)
    {
        j=quadraticProbe(i,size, ogHash);
        if (table[j]==key)
        {
            return true;
        }
        else if (table[j]==-2)
        {
            return false;
        }
    }
    return false;
}
int HashTable::InsertMQP(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=multiplicationMethod(key,size);
    for(i=0;i<size;i++)
    {
        j=quadraticProbe(i, size, ogHash);
        if(table[j] == -2 || table[j] == -1)
        {
            table[j] = key;
            return j;
        }
    }    
    return -2;
}
int HashTable::DeleteMQP(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=multiplicationMethod(key,size);
    for(i = 0; i < size; i++)
    {
        j=quadraticProbe(i, size, ogHash);
        if (table[j]==key)
        {
            table[j]=-1;
            return j;
        }
        else if (table[j]==-2)
        {
            return -2;
        }
    }
    return -2;
}




//---------------------------DIVISION DOUBLE HASH------------------------
bool HashTable::SearchDDH(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=divisionMethod(key,size);
    for(i = 0; i < size; i++)
    {
        j=doubleHash(i,size, ogHash);
        if (table[j]==key)
        {
            return true;
        }
        else if (table[j]==-2)
        {
            return false;
        }
    }
    return false;
}
int HashTable::InsertDDH(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=divisionMethod(key,size);
    for(i=0;i<size;i++)
    {
        j=doubleHash(i, size, ogHash);
        if(table[j] == -2 || table[j] == -1)
        {
            table[j] = key;
            return j;
        }
    }    
    return -2;
}
int HashTable::DeleteDDH(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=divisionMethod(key,size);
    for(i = 0; i < size; i++)
    {
        j=doubleHash(i, size, ogHash);
        if (table[j]==key)
        {
            table[j]=-1;
            return j;
        }
        else if (table[j]==-2)
        {
            return -2;
        }
    }
    return -2;
}




//---------------------------MULTIPLICATION DOUBLE HASH------------------------
bool HashTable::SearchMDH(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=multiplicationMethod(key,size);
    for(i = 0; i < size; i++)
    {
        j=doubleHash(i,size, ogHash);
        if (table[j]==key)
        {
            return true;
        }
        else if (table[j]==-2)
        {
            return false;
        }
    }
    return false;
}
int HashTable::InsertMDH(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=multiplicationMethod(key,size);
    for(i=0;i<size;i++)
    {
        j=doubleHash(i, size, ogHash);
        if(table[j] == -2 || table[j] == -1)
        {
            table[j] = key;
            return j;
        }
    }    
    return -2;
}
int HashTable::DeleteMDH(int key)
{
    long unsigned int i=0;
    int j;
    int ogHash=multiplicationMethod(key,size);
    for(i = 0; i < size; i++)
    {
        j=doubleHash(i, size, ogHash);
        if (table[j]==key)
        {
            return j;
            table[j]=-1;
        }
        else if (table[j]==-2)
        {
            return -2;
        }
    }
    return -2;
}

#endif
